package com.cognizant.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;

import com.cognizant.model.Register;
import com.cognizant.util.DBUtil;

public class RegisterDao {
	public Register registerUser(Register r)
	{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			System.out.println("Hello worl");
			conn=DBUtil.getConnection();			
			String s="insert into dabba1 values(?,?,?,?,?,?)";
			ps=conn.prepareStatement(s);
			ps.setString(1,r.getCid());
			ps.setString(2, r.getName());
			ps.setString(3, r.getPassword());
			ps.setString(4, r.getEmail());
			ps.setString(5, r.getDateOfBirth());
			ps.setString(6, r.getContact());
			rs=ps.executeQuery();
			while(rs.next())
			{
				r.setCid(rs.getString("cid"));
				r.setName(rs.getString("name"));
				r.setPassword(rs.getString("pass"));
				r.setEmail(rs.getString("email"));
				r.setDateOfBirth(rs.getString("dob"));
				r.setContact(rs.getString("contact"));
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return r;
	}
}
