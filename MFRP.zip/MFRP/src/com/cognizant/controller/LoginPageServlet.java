package com.cognizant.controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String cid=request.getParameter("customerId");
		String cno=request.getParameter("contactNo");
		String pass=request.getParameter("pass");
		if(){
			response.sendRedirect("welcome.html");
		}else{
			response.sendRedirect("index.html");
		}
	}
}