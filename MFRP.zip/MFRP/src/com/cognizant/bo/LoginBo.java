package com.cognizant.bo;

import com.cognizant.Dao.LoginDao;
import com.cognizant.model.LoginTO;

public class LoginBo {
	public boolean validateUser(LoginTO login){
		LoginDao logindao=new LoginDao();
		LoginTO l=logindao.validateuser(login);
		if(l!=null && l.getCid().equals(login.getCid())&&l.getContactNo().equals(login.getContactNo())&&l.getPass().equals(login.getPass()))
			return true;
		else
			return false;
	}
}
