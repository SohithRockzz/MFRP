package com.cognizant.bo;

import com.cognizant.Dao.RegisterDao;
import com.cognizant.model.Register;

public class RegisterBo {
	public Register registerUser(Register r)
	{
		RegisterDao rd=new RegisterDao();
		return rd.registerUser(r);
		
	}
}
