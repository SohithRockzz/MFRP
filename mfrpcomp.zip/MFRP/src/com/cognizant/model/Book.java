package com.cognizant.model;

public class Book {
	private int cat_id;
	private int book_id;
	private String book_name;
	private int price;
	private int availability;
	private String binding;
	private String language;
	private String author_name;
	private String publisher_name;
	private String delivery_time;
	
	
	
	public int getCat_id() {
		return cat_id;
	}
	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getAvailability() {
		return availability;
	}
	public void setAvailability(int availability) {
		this.availability = availability;
	}
	public String getBinding() {
		return binding;
	}
	public void setBinding(String binding) {
		this.binding = binding;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getAuthor_name() {
		return author_name;
	}
	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}
	public String getPublisher_name() {
		return publisher_name;
	}
	public void setPublisher_name(String publisher_name) {
		this.publisher_name = publisher_name;
	}
	public String getDelivery_time() {
		return delivery_time;
	}
	public void setDelivery_time(String delivery_time) {
		this.delivery_time = delivery_time;
	}
	
	public Book(int cat_id, int book_id, String book_name, int price,
			int availability, String binding, String language,
			String author_name, String publisher_name, String delivery_time) {
		super();
		this.cat_id = cat_id;
		this.book_id = book_id;
		this.book_name = book_name;
		this.price = price;
		this.availability = availability;
		this.binding = binding;
		this.language = language;
		this.author_name = author_name;
		this.publisher_name = publisher_name;
		this.delivery_time = delivery_time;
	}
	public Book() {
		super();
	}
	
	
	
}
