package com.cognizant.util;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection conn=null;

	public static Connection getConnection(){
		if(conn!=null){
			return conn;
		}
		else
		{
			try{
				Class.forName("oracle.jdbc.OracleDriver");
				conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system","password-1");
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return conn;
	}
}