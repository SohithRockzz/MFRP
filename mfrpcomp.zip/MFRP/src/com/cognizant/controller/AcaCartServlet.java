package com.cognizant.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.Dao.AcaDao;
import com.cognizant.model.Book;

/**
 * Servlet implementation class AcaCartServlet
 */
public class AcaCartServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession sess=request.getSession();
		String s=request.getParameter("bname");
		Book b=new Book();
		AcaDao adao=new AcaDao();
		b=adao.getBookDetails(s);
		request.setAttribute("bookobject", b);
		RequestDispatcher rd=request.getRequestDispatcher("cart.jsp");
		rd.forward(request, response);
	}

}
