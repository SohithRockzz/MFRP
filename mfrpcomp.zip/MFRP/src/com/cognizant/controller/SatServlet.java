package com.cognizant.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.Dao.CatDao;
import com.cognizant.Dao.SatDao;
import com.cognizant.bo.CatBo;
import com.cognizant.bo.SatBo;
import com.cognizant.model.Book;

/**
 * Servlet implementation class SatServlet
 */
public class SatServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Book b=new Book();
		SatBo bbo=new SatBo();
		List<Book> list=new ArrayList<Book>();
			list=SatDao.getSatBooks();
		HttpSession sess=request.getSession();
		request.setAttribute("Booklist", list);
		RequestDispatcher rd=request.getRequestDispatcher("sat.jsp");
		rd.forward(request, response);
	}

}
