package com.cognizant.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.bo.RegisterBo;
import com.cognizant.model.Register;

public class RegisterPageServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Random rand = new Random();
		String cid= String.format("%04d", rand.nextInt(10000));
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		String email=request.getParameter("email");
		String dob=request.getParameter("dob");
		String cno=request.getParameter("contactNo");
		
		Register r=new Register();
		r.setCid(cid);
		r.setName(name);
		r.setPassword(pass);
		r.setEmail(email);
		r.setDateOfBirth(dob);
		r.setContact(cno);
		request.getParameter("name");
		request.getParameter("pass");
		request.getParameter("email");
		request.getParameter("dob");
		request.getParameter("contactNo");
		
		RegisterBo rbo=new RegisterBo();
		rbo.registerUser(r);
		HttpSession sess=request.getSession();
		sess.setAttribute("r", r);
		response.sendRedirect("showRegister.jsp");
		
	}

}
