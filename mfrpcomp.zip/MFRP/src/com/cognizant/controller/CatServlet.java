package com.cognizant.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.Dao.AcaDao;
import com.cognizant.Dao.CatDao;
import com.cognizant.bo.AcaBo;
import com.cognizant.bo.CatBo;
import com.cognizant.model.Book;

/**
 * Servlet implementation class CatServlet
 */
public class CatServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Book b=new Book();
		CatBo bbo=new CatBo();
		List<Book> list=new ArrayList<Book>();
			list=CatDao.getCatBooks();
		HttpSession sess=request.getSession();
		request.setAttribute("Booklist", list);
		RequestDispatcher rd=request.getRequestDispatcher("cat.jsp");
		rd.forward(request, response);
	}

}
