package com.cognizant.controller;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.bo.LoginBo;
import com.cognizant.model.LoginTO;

public class LoginPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String cid=request.getParameter("customerId");
		String cno=request.getParameter("contactNo");
		String pass=request.getParameter("pass");
		LoginTO loginTo=new LoginTO();
		loginTo.setCid(cid);
		loginTo.setContactNo(cno);
		loginTo.setPass(pass);
		LoginBo login=new LoginBo();
		if(login.validateUser(loginTo)){
		
			RequestDispatcher rd=request.getRequestDispatcher("loginsuccess.jsp");
			rd.forward(request,response);

		}else{
			PrintWriter pw=response.getWriter();
			pw.println("<html><head>");
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Invalid Username and Password');");
			pw.println("</script>");
			pw.println("</head><body></body></html>");
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.include(request,response);
		}
	}
}