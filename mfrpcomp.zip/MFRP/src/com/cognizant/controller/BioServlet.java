package com.cognizant.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.Dao.BioDao;
import com.cognizant.bo.BioBO;
import com.cognizant.model.Book;
public class BioServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Book b=new Book();
		BioBO bbo=new BioBO();
		List<Book> list=new ArrayList<Book>();
			list=BioDao.getBioBooks();
		HttpSession sess=request.getSession();
		request.setAttribute("Booklist", list);
		RequestDispatcher rd=request.getRequestDispatcher("bio.jsp");
		rd.forward(request, response);
	}
}
