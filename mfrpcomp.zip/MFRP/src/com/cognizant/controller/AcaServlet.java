package com.cognizant.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cognizant.Dao.AcaDao;
import com.cognizant.Dao.BioDao;
import com.cognizant.bo.AcaBo;
import com.cognizant.bo.BioBO;
import com.cognizant.model.Book;

/**
 * Servlet implementation class AcaServlet
 */
public class AcaServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Book b=new Book();
		AcaBo bbo=new AcaBo();
		List<Book> list=new ArrayList<Book>();
			list=AcaDao.getAcaBooks();
		HttpSession sess=request.getSession();
		request.setAttribute("Booklist", list);
		RequestDispatcher rd=request.getRequestDispatcher("aca.jsp");
		rd.forward(request, response);
	}
}
