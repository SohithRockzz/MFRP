package com.cognizant.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.model.Book;
import com.cognizant.util.DBUtil;

public class AcaDao {
	public static List<Book> getAcaBooks()
	{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Book b=new Book();
		List<Book> list=new ArrayList<Book>();
		try{
			conn=DBUtil.getConnection();
			String s="select * from book where cat_id=30001";
			ps=conn.prepareStatement(s);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				list.add(new Book(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10)));
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	public Book getBookDetails(String s) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Book b=new Book();
		try{
			conn=DBUtil.getConnection();
			ps=conn.prepareStatement("select * from book where book_name=?");
			ps.setString(1, s);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				b=new Book(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return b;
	}
}
