package com.cognizant.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cognizant.model.LoginTO;
import com.cognizant.util.DBUtil;

public class LoginDao {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		
		public LoginTO validateUser(LoginTO loginTo)
		{
			System.out.println("Helooo");
			LoginTO l=null;
			try{
				conn=DBUtil.getConnection();
				System.out.println("ghfg");
				String s="select cid,contact from dabba1 where pass=?";
				System.out.println(loginTo.getPass());
				ps=conn.prepareStatement(s);
				ps.setString(1, loginTo.getPass());
				rs=ps.executeQuery();
				if(rs.next())
				{
					l=new LoginTO();
					l.setCid(rs.getString("cid"));
					l.setContactNo(rs.getString("contact"));
					l.setPass(loginTo.getPass());
				}
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			return l;
		}			
}
