package com.cognizant.bo;

import java.util.List;

import com.cognizant.Dao.AcaDao;
import com.cognizant.Dao.CatDao;
import com.cognizant.model.Book;

public class CatBo {
	public List<Book> getCatBooks()
	{
		CatDao cdao=new CatDao();
		List<Book> catList=cdao.getCatBooks();
		return catList;
	}
}
