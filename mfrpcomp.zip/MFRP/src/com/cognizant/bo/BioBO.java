package com.cognizant.bo;

import java.util.List;

import com.cognizant.Dao.BioDao;
import com.cognizant.model.Book;

public class BioBO {
		public List<Book> getBioBooks()
		{
			
			BioDao bdao=new BioDao();
			List<Book> bioList=bdao.getBioBooks();
			return bioList;
		}
}
