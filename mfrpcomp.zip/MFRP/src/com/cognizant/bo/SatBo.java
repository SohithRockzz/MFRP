package com.cognizant.bo;

import java.util.List;

import com.cognizant.Dao.SatDao;
import com.cognizant.model.Book;

public class SatBo {
	public List<Book> getCatBooks()
	{
		SatDao sdao=new SatDao();
		List<Book> satList=sdao.getSatBooks();
		return satList;
	}
}
