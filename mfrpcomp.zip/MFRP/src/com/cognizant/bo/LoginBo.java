package com.cognizant.bo;

import com.cognizant.Dao.LoginDao;
import com.cognizant.model.LoginTO;

public class LoginBo {
	public boolean validateUser(LoginTO loginTo){
		LoginDao logindao=new LoginDao();
		LoginTO l=logindao.validateUser(loginTo);
		if(l!=null&&(l.getCid().equals(loginTo.getCid())&& l.getContactNo().equals(loginTo.getContactNo())&&l.getPass().equals(loginTo.getPass())))
			return true;
		else
			return false;
	}
}
