package com.cognizant.bo;

import java.util.List;

import com.cognizant.Dao.AcaDao;
import com.cognizant.Dao.BioDao;
import com.cognizant.model.Book;

public class AcaBo {
	public List<Book> getAcaBooks()
	{
		
		AcaDao adao=new AcaDao();
		List<Book> acaList=adao.getAcaBooks();
		return acaList;
	}
	public Book getBookDetails(String s)
	{
		AcaDao adao=new AcaDao();
		Book b=new Book();
		b=adao.getBookDetails(s);
		return b;
	}
}
