package com.cognizant.bo;

import java.util.List;

import com.cognizant.Dao.AcaDao;
import com.cognizant.Dao.LitDao;
import com.cognizant.model.Book;

public class LitBo {
	public List<Book> getLitBooks()
	{
		
		LitDao ldao=new LitDao();
		List<Book> litList=ldao.getLitBooks();
		return litList;
	}
}
